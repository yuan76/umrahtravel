<?php
$host ="localhost:3306";
$pass ="";
$user ="root";
$dbname ="hatikuum_sf_db019";

$conn = mysqli_connect($host, $user, $pass, $dbname);
/*
if ($conn->connect_error) {
  echo $conn->connect_error;
} else {
  echo "konek loh";
}
*/
?>
<?php
	//error_reporting(0);

	include "koneksi.php";
	include "readNope.php";
	
	$username=strtolower($_GET['username']);
    $qry = mysqli_query($conn,"select nomor FROM orderlink WHERE username='$username'");
		
	while ($data=mysqli_fetch_row($qry)){
		$nope=$data[0];			
	}
	//echo $nope;
	
	$nopeba=substr(read_no($conn,$dbname,$nope),1);
	//echo $nopeba;

	header("Location: https://api.whatsapp.com/send?phone=$nopeba&text=Assalamualaikum");

?>
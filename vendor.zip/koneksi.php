<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<?php
$host ="localhost:3306";
$pass ="oemi1996";
$user ="root";
$dbname ="htki";

$conn = mysqli_connect($host, $user, $pass, $dbname);
/*
if ($conn->connect_error) {
  echo $conn->connect_error;
} else {
  echo "konek loh";
}
*/
?>
</body>
</html>
